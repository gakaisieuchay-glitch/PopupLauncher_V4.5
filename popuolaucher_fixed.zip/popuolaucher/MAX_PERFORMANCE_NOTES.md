# Popup Launcher — MAX Performance Pass

## Goal

This pass does not add background polling, analytics, extra services, or heavy dependencies. It targets the actual hot paths on low-end devices.

## 1. Touch -> Frame

The bubble drag path is frame-coalesced with `postOnAnimation()`. Multiple MotionEvents arriving inside the same display frame collapse into one `WindowManager.updateViewLayout()` call. This reduces binder/UI churn without making the bubble feel less responsive.

Hardware layer is enabled only after the drag threshold and is disabled after release/cancel. System gesture exclusion is enabled only during active drag.

## 2. Overlay Touch Contention

The bubble and panel use `FLAG_NOT_TOUCH_MODAL` so touches outside the actual overlay window are not unnecessarily captured from the game underneath.

## 3. App List

Installed-app enumeration is cached until package/favorite/usage changes. Package changes invalidate the cache through a process-local receiver instead of polling PackageManager.

`AppEntry.searchKey` precomputes Vietnamese normalization, initials and package-name search data once. Search then performs a linear O(N) substring pass without re-running Unicode normalization for every app on every keystroke.

RecyclerView uses stable row sizing, no item animations, no overscroll and a small recycled pool suitable for low-RAM devices. Filtering uses `ListAdapter + DiffUtil` instead of `notifyDataSetChanged()`.

## 4. Launch Critical Path

Priority remains:

1. Root
2. Shizuku UserService
3. Public Android `ActivityOptions.setLaunchBounds()` fallback

The panel pre-warms Root/Shizuku while the user is browsing the app list. This hides privilege/Binder setup latency behind work the user is already waiting for.

The app does not claim that end-to-end application startup can always be <10 ms. That includes target-app process creation, framework scheduling, rendering and OEM policy. The realistic optimization target is keeping Popup Launcher's own dispatch/IPC preparation small and off the Main thread.

## 5. Shizuku Race Safety

A bind timeout can race with `onServiceConnected()`. The manager now rejects late callbacks after cancellation and immediately unbinds a stale service, preventing a rare leaked UserService/Binder state.

## 6. Root Session

A pooled interactive `su` session is reused for short bursts and released when idle. This avoids repeated `su` process startup while preserving one-off fallback behavior when the pooled pipe fails.

## 7. Overlay Recovery

`FloatingService` checks `SYSTEM_ALERT_WINDOW` before creating the overlay and catches `WindowManager` add failures. This prevents a revoked overlay permission/OEM denial from turning into a service process crash.

Configuration changes clamp the bubble back into the current safe display area.

## 8. What was deliberately NOT put in the hot path

- `fstrim`
- `cmd package bg-dexopt-job`
- forced refresh-rate pinning
- periodic Shizuku polling
- periodic CPU wakeups
- extra Accessibility/overlay services
- network/analytics

Those operations either add I/O/thermal load or do not directly improve popup launch/frame latency.

## 9. Benchmark target on a low-end 60 Hz device

Use Perfetto/FrameTimeline and `dumpsys gfxinfo` to measure rather than judging by animation alone.

Desired behavior:

- Idle bubble: no repeating Runnable/Animator; only one delayed fade callback when needed.
- Drag: at most one overlay layout update per vsync frame.
- Search: no PackageManager calls while typing.
- Launch: Root/Shizuku preparation overlaps with panel browsing whenever possible.
- Panel close: listener, adapter, RecyclerView and panel-owned coroutines are detached/cancelled before the overlay View is removed.
