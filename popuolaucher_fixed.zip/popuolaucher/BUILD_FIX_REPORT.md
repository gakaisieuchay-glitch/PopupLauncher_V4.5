# Popup Launcher – Build Fix Report

## Failure source from GitHub Actions

The uploaded build log shows that the CI environment successfully completed project discovery, Java 17, Android SDK, Gradle, project validation, Android configuration validation, and source checks. The actual failure is Kotlin compilation during `:app:lintDebug`.

Primary compiler errors:

- `FloatingService.kt:867`: constructor parameter is `initialItems`, but caller passed `items`.
- `IShellCommandService` unresolved throughout `ShellCommandService.kt`, `ShizukuManager.kt`, and `OptimizationManager.kt`.
- Because the generated AIDL type was missing, the compiler reported cascading `overrides nothing`, `Unresolved reference`, and wrong inferred `Unit` errors.
- `ShizukuManager.kt:180`: `return` was used inside an expression-body function.
- `OverlayBoundsCalculator.kt:31`: direct `WindowInsets.Type.waterfall()` reference was removed in favour of `systemBars + displayCutout`, avoiding a vendor/stub resolution failure while preserving the important notch/system-bar safety behavior.

## Fixes applied

1. `app/build.gradle.kts`
   - Explicitly enables AIDL generation with `buildFeatures { aidl = true }`.
   - This makes the `IShellCommandService.aidl` source an explicit build contract instead of relying on AGP defaults.

2. `FloatingService.kt`
   - `items = allApps` -> `initialItems = allApps`.

3. `ShizukuManager.kt`
   - Converted `runWithService` to a block body so early `return` is legal.
   - Kept the existing Shizuku UserService lifecycle and timeout design.

4. `OverlayBoundsCalculator.kt`
   - Removed direct `WindowInsets.Type.waterfall()` usage.
   - Uses `systemBars()` and `displayCutout()` for the safe launch rectangle.

5. Top-level `build.gradle.kts`
   - Replaced deprecated `rootProject.buildDir` access with `rootProject.layout.buildDirectory`.

## AIDL contract

`app/src/main/aidl/com/example/popuplauncher/IShellCommandService.aidl` remains at the correct package path and its Shizuku destroy transaction remains `16777114` in the AIDL file, matching the Shizuku UserService contract.

## Verification limit

The container used for this edit does not have a local Gradle distribution or Android SDK toolchain cache, and direct distribution download is unavailable. Therefore this archive has been statically repaired and checked against the exact CI compiler errors; an actual `assembleRelease` must still be performed by GitHub Actions.
