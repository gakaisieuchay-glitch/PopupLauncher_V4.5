# Super Boost (OptimizationManager)

Integrated from the two PDF transcripts, with fixes and a few adaptations to this
project's actual architecture. Nothing here needed a new Android permission: every
privileged command runs as shell/root identity via Root or Shizuku (the same
mechanism the app already uses to launch floating windows), so it's the same trust
boundary as the rest of the app, not a new one.

## What each step does (all standard, documented adb-shell commands)

1. `IconCache.clear()` — always available, no privilege needed.
2. `am kill-all` — asks the system to reclaim idle/cached background processes now.
3. `cmd package bg-dexopt-job` — nudges ART to background-compile frequently used apps.
4. `sm fstrim` — trims unused storage blocks (I/O speed).
5. `settings put system peak_refresh_rate/min_refresh_rate` — locks the refresh rate.

`disableSuperBoost()` only reverts step 5 (`settings delete ...`). Steps 1-4 are
one-shot actions with nothing meaningful to "undo."

## Fixed from the PDF version

- **Same regex bug** as Phase 2 (`\\d`/`\\s`/`\\b` in a raw string) was present in the
  PDF's `ShellCommandService.findTaskId` — fixed the same way.
- **Missing AIDL methods**: the PDF added `killAppProcess()` / `trimBackgroundProcesses()`
  as plain Kotlin methods on `ShellCommandService`, but never added them to
  `IShellCommandService.aidl`. Without that, they're not remotely callable at all —
  Binder only exposes what's declared in the `.aidl` interface. Added both to the AIDL
  and wired `trimBackgroundProcesses()` into the boost flow.
- **Root-first routing**: the PDF version only ever went through the Shizuku
  `shellService`, with no Root path — inconsistent with this app's own Priority Launch
  Engine (Root first, Shizuku second, everywhere else). `OptimizationManager` now tries
  `RootManager` first via a new `RootManager.runCommand()` and `ShizukuManager
  .withShellService()` entry point (both reuse the same pooled session/bind from
  Phase 2 — a boost run doesn't pay a second bind cost on top of a popup launch).
- **Refresh-rate device check**: the PDF hardcoded `120.0` unconditionally. Forcing an
  unsupported refresh rate on a panel that only does 60Hz is either a silent no-op or,
  on some ROMs, a value the system just ignores — this version reads
  `Display.getSupportedModes()` and skips the step (with a log line) if the display
  doesn't support anything above 60Hz.

## Deliberately not carried over

- **`System.gc()` calls**: removed. Explicit `System.gc()` is generally discouraged on
  Android — it can force a stop-the-world pause without a guaranteed reduction in
  actual memory pressure. `IconCache.clear()` alone does the intended job (drop the
  strong references; let the GC reclaim them on its own schedule).
- **Jetpack Compose UI**: the PDF's toggle was a `@Composable PerformanceBoosterSection`.
  This project has no Compose dependency, no `buildFeatures.compose`, and no other
  Compose UI anywhere — adding the whole toolkit for one switch would be a large,
  unrelated build-system change and works against the project's stated "no
  nhồi thư viện thừa" (don't bloat with extra libraries) philosophy. The same toggle is
  implemented as a plain `Switch` in `MainActivity`'s existing programmatic-view screen
  instead — same behavior, no new UI framework.

## The one trade-off worth understanding before you flip the switch

`am kill-all` is blunt: it reclaims *idle* background processes, not the one app you
have in mind. It won't force-stop something actively working (music playback, a
foreground service), but it can end an idle background process a moment before, say,
a chat app would have received a push notification. If you want to target one
specific app instead, `killAppProcess(packageName)` (`am force-stop`) is already wired
into `ShellCommandService` and is the scoped alternative — just not hooked into the
Super Boost switch itself, so it doesn't surprise anyone who only wanted "make Pop-ups
smoother," not "close a specific app."
