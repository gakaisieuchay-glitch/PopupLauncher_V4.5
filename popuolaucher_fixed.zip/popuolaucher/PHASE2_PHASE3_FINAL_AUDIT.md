# Popup Launcher — Phase 2 + Phase 3 Final Audit

## Implemented
- Rebuilt `ShizukuManager.kt` as a single, valid Shizuku gateway.
- Stable Shizuku UserService `tag` + version to make R8-safe service identity.
- Shizuku permission result uses Shizuku's dedicated permission-result listener.
- One shared UserService connection, 3.5s bind timeout, 8s idle unbind.
- `runWithService()` compatibility API retained for Phase 2 callers.
- Launch priority remains Root -> Shizuku -> native ActivityOptions.
- Hardware layer enabled only while bubble is actively dragged; disabled on UP/CANCEL/removal.
- Removed duplicate `WindowManager.updateViewLayout()` call.
- Added a lightweight Quick Settings tile to start/stop `FloatingService`.
- Added low-memory icon-cache eviction from `Application.onTrimMemory()`.
- No new third-party dependency was added for Phase 3.

## Intentional non-features
No analytics, network calls, notification listeners, accessibility service, extra overlay windows, database tables, or background polling were added.

## Build limitation
Local build could not be executed because the environment cannot resolve/download Gradle 8.9 from `services.gradle.org`. The GitHub Actions workflow is retained as the build authority.

## Static checks
- AndroidManifest.xml parses successfully.
- strings.xml parses successfully.
- Kotlin files have balanced braces.
- `ShizukuManager` contains exactly one manager declaration and no embedded `ShellCommandService` declaration.
