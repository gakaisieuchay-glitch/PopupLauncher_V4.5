package com.example.popuplauncher.utils

import android.view.View

/**
 * Enables a hardware layer only during active drag/translation.
 * A persistent hardware layer would waste GPU memory on low-RAM phones; keeping it transient
 * avoids retaining an extra cached layer while the bubble is idle.
 */
object OverlayRenderOptimizer {

    fun enableHardwareLayer(view: View) {
        if (view.layerType != View.LAYER_TYPE_HARDWARE) {
            view.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        }
    }

    fun disableHardwareLayer(view: View) {
        if (view.layerType != View.LAYER_TYPE_NONE) {
            view.setLayerType(View.LAYER_TYPE_NONE, null)
        }
    }
}
